# Platform Runner 3D

Complete Unity project (Unity 6, Built-in render pipeline, no imported art required).

## Open it
1. Unzip this folder anywhere (not inside a cloud-synced folder).
2. Unity Hub > Add > Add project from disk > pick this folder.
3. Pick any installed Unity 6 (6000.x) editor when Hub asks. First open takes a few minutes (package import).
4. When it finishes, the 4 scenes are created automatically (console: "scenes created") and MainMenu opens.
5. Press Play.

If the scenes did not appear: menu Platform Runner > Build Everything.

## Controls
A / D or arrows = change lane, Space / W / Up = jump, S / Down = slide, Esc / P = pause.
Touch / mouse drag: swipe left, right, up, down.

## Add your own art and sound
Put prefabs and audio in Assets/Resources with the names listed in the README.txt files there.
